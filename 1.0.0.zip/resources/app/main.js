const { app, BrowserWindow } = require('electron');

function createWindow() {
  const isDebugMode = false;
  const win = new BrowserWindow({
    width: 1920,
    height: 1080,
    //fullscreen: true,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      plugins: true,
    }
  });

  if (isDebugMode) {
    // Debug mode
    win.webContents.openDevTools();

    win.loadURL('https://health-hub-feature.vmedia.ca');
  } else {
    // Disable menu
    win.setMenu(null);

    // Load resource
    win.loadURL('https://health-hub-feature.vmedia.ca');
  }

  // Clear LocalStorage before closing the window
  win.on('close', () => {
    win.webContents.executeJavaScript(`
      localStorage.clear();
    `);
  });

}

app.whenReady().then(() => {
  createWindow();

  app.on('activate', function () {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });

});

app.on('window-all-closed', function () {
    app.quit();
});