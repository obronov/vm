const { app, BrowserWindow, session } = require('electron');

function createWindow() {
  const isDebugMode = false;
  const win = new BrowserWindow({
    width: 1920,
    height: 1080,
    //fullscreen: true,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      plugins: true,
    }
  });

  if (isDebugMode) {
    // Debug mode
    win.webContents.openDevTools();

    win.loadURL('https://health-hub-feature.vmedia.ca');
  } else {
    // Disable menu
    win.setMenu(null);

    // Load resource
    win.loadURL('https://health-hub-feature.vmedia.ca');
  }

}

app.whenReady().then(() => {
  createWindow();

  app.on('activate', function () {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on('window-all-closed', function () {
  app.quit();
});

app.on('before-quit', async (event) => {
  event.preventDefault();

  // Clear cache before closing the window
  await session.defaultSession.clearCache();
  await session.defaultSession.clearStorageData();
  app.exit();
});